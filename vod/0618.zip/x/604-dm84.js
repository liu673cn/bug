{
  "author":"Tangsan99999",
  "ua": "",
  "homeUrl": "https://dm84.tv",
  "cateNode": "//ul[contains(@class,'nav_row')]/li/a[contains(@href, '.html')]",
  "cateName": "/text()",
  "cateId": "/@href",
  "cateIdR": "/list-(\\d+).html",
  "cateManual": {},
  "homeVodNode": "//ul[@class='v_list']/li/div[@class='item']",
  "homeVodName": "/a[@class='title']/@title",
  "homeVodId": "/a[@class='title']/@href",
  "homeVodIdR": "/v/(\\w+).html",
  "homeVodImg": "/a/@data-bg",
  "homeVodMark": "/span[@class='desc']/text()",
  "cateUrl": "https://dm84.tv/show-{cateId}--{by}-{catelog}--{year}-{catePg}.html",
  "cateVodNode": "//ul[@class='v_list']/li/div[@class='item']",
  "cateVodName": "/a[@class='title']/@title",
  "cateVodId": "/a[@class='title']/@href",
  "cateVodIdR": "/v/(\\w+).html",
  "cateVodImg": "/a/@data-bg",
  "cateVodMark": "/span[@class='desc']/text()",
  "dtUrl": "https://dm84.tv/v/{vid}.html",
  "dtNode": "//body",
  "dtName": "//h1[@class='v_title']/a/text()",
  "dtImg": "//div[@class='cover']/img/@src",
  "dtCate": "concat(//p[@class='v_desc']/a/text())",
  "dtCateR": "",
  "dtYear": "//p[@class='v_desc']/text()",
  "dtYearR": "",
  "dtArea": "//p[@class='v_desc']/text()[2]",
  "dtAreaR": "",
  "dtMark": "",
  "dtMarkR": "",
  "dtActor": "//p[contains(text(),'主演')]/text()",
  "dtActorR": "\\S+：(\\S+)",
  "dtDirector": "//p[contains(text(),'导演')]/text()",
  "dtDirectorR": "\\S+：(\\S+)",
  "dtDesc": "//p[contains(text(),'剧情')]/text()",
  "dtDescR": "\\S+：(\\S+)",
  "dtFromNode": "//ul[contains(@class,'play_from')]/li",
  "dtFromName": "/text()",
  "dtUrlNode": "//ul[contains(@class,'play_list')]",
  "dtUrlSubNode": "/li/a",
  "dtUrlId": "@href",
  "dtUrlIdR": "/p/(\\S+).html",
  "dtUrlName": "/text()",
  "playUrl": "https://dm84.tv/p/{playUrl}.html",
  "searchUrl": "https://dm84.tv/s----------.html?wd={wd}",
  "scVodNode": "//ul[@class='v_list']/li/div[@class='item']",
  "scVodName": "/a[@class='title']/@title",
  "scVodId": "/a[@class='title']/@href",
  "scVodIdR": "/v/(\\w+).html",
  "scVodImg": "/a/@data-bg",
  "scVodMark": "/span[@class='desc']/text()",
  "filter": {
    "1": [
      {
        "key": "catelog",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "奇幻","v": "奇幻"},
          {"n": "战斗","v": "战斗"},
          {"n": "玄幻","v": "玄幻"},
          {"n": "穿越","v": "穿越"},
          {"n": "科幻","v": "科幻"},
          {"n": "武侠","v": "武侠"},
          {"n": "热血","v": "热血"},
          {"n": "耽美","v": "耽美"},
          {"n": "搞笑","v": "搞笑"},
          {"n": "动态漫画","v": "动态漫画"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "2": [
      {
        "key": "catelog",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "冒险","v": "冒险"},
          {"n": "奇幻","v": "奇幻"},
          {"n": "战斗","v": "战斗"},
          {"n": "后宫","v": "后宫"},
          {"n": "热血","v": "热血"},
          {"n": "励志","v": "励志"},
          {"n": "搞笑","v": "搞笑"},
          {"n": "校园","v": "校园"},
          {"n": "机战","v": "机战"},
          {"n": "悬疑","v": "悬疑"},
          {"n": "治愈","v": "治愈"},
          {"n": "百合","v": "百合"},
          {"n": "恐怖","v": "恐怖"},
          {"n": "泡面番","v": "泡面番"},
          {"n": "恋爱","v": "恋爱"},
          {"n": "推理","v": "推理"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "3": [
      {
        "key": "catelog",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "科幻","v": "科幻"},
          {"n": "冒险","v": "冒险"},
          {"n": "战斗","v": "战斗"},
          {"n": "百合","v": "百合"},
          {"n": "奇幻","v": "奇幻"},
          {"n": "热血","v": "热血"},
          {"n": "搞笑","v": "搞笑"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "4": [
      {
        "key": "catelog",
        "name": "类型",
        "value": [
          {"n": "全部","v": ""},
          {"n": "搞笑","v": "搞笑"},
          {"n": "奇幻","v": "奇幻"},
          {"n": "治愈","v": "治愈"},
          {"n": "科幻","v": "科幻"},
          {"n": "喜剧","v": "喜剧"},
          {"n": "冒险","v": "冒险"},
          {"n": "动作","v": "动作"},
          {"n": "爱情","v": "爱情"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ]
  }
}
